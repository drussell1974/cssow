This github/linguist#1 and #1 'is' surprising.
And so &#39;is&#39; this.

## Code like `foo` enclosed in 'backquotes':

```py
def fib(n):    # write Fibonacci series up to n
    a, b = 0, 1
    while b < n:
        print b,
        a, b = b, a+b

# Now call the function we just defined:
fib(2000)
```


